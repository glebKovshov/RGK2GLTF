#include <iostream>
#include <RGK/Common/Session.h>
#include <RGK/Common/Context.h>
#include <RGK/Common/Instance.h>
#include <RGK/Common/Result.h>
#include <RGK/Math/LCS3D.h>
#include <RGK/Math/Vector3D.h>
#include <RGK/Generators/PrimitiveGenerator.h>
#include <RGK/Generators/Faceter.h>
#include <RGK/Topols/Body.h>
#include <RGK/Utils/Storage.h>
#include <RGK/Geometry/Geometry.h>
#include <RGK/Math/Vector3D.h>
#include <fstream>

void Check_result(RGK::Common::Result& result, std::string Fname, bool break_if_fail = false) {

    std::string offset;
    if (Fname.size() >= 50)
    {
        Fname.erase(44, Fname.size() - 1);
        Fname += "...  ";
        offset = "";
    }
    else offset = std::string((49 - Fname.size()), ' ');

    if (RGK::Failed(result))
    {
        std::cout << Fname << offset << " FAIL: " << RGK::Common::ResultToString(result) << std::endl;
        if (break_if_fail)
        {
            RGK::Common::Instance::End();
            std::cout << "Press ENTER to continue...\n";
            std::cin.get();
            exit(0);
        }
    }
    else
        std::cout << Fname << offset << " SUCCESS\n";
}

void CreateMeshPoints(RGK::Common::Context apicontext, RGK::Topols::Body body, std::string FName, double SideLengthTorelance = 0.5) {
    RGK::Generators::Faceter::Data facetData;
    facetData.AddBody(body);

    facetData.SetNormalAngleTolerance(0.2);
    facetData.SetSideLengthTolerance(SideLengthTorelance);
    facetData.SetMeshMode(RGK::Generators::Faceter::MeshMode::TriangleMeshing);
    RGK::Generators::Faceter::Report facetReport;

    std::ofstream fout(FName);

    auto result = RGK::Generators::Faceter::Create(apicontext, facetData, facetReport);
    Check_result(result, "Faceter::Create");

    auto mesh = facetReport.GetMesh();
    
    for (auto ii = mesh.GetValidFacesBegin(); ii != mesh.GetValidFacesEnd(); ++ii)
    {
        auto face = *ii;
        auto edge = mesh.GetFaceEdge(face);
        auto  prevEdge = mesh.GetEdgePrev(edge);
        auto  nextEdge = mesh.GetEdgeNext(edge);

        auto point1 = mesh.GetXYZ(prevEdge);
        auto point2 = mesh.GetXYZ(edge);
        auto point3 = mesh.GetXYZ(nextEdge);

        //�������� ���������� ����� � ����

        fout << point1.GetX() << " " << point1.GetY() << " " << point1.GetZ() << std::endl;
        fout << point2.GetX() << " " << point2.GetY() << " " << point2.GetZ() << std::endl;
        fout << point3.GetX() << " " << point3.GetY() << " " << point3.GetZ() << std::endl;
    }
}