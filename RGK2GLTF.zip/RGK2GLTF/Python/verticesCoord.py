file = open("values.txt", "r")
vertices = []
for line in file:
    vertex = list(map(float, line.split(" ")))
    vertices.append(vertex)